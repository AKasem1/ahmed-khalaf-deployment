import React from 'react'

const Arrow = () => {
  return (
    <div className="arrow-animation">
        <span></span>
        <span></span>
        <span></span>
    </div>
  )
}
export default Arrow;
